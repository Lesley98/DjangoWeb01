$(function() {

    $('#search').focus();
});
