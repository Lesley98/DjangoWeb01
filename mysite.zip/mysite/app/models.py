from django.db import models

class Source(models.Model):
    id = models.AutoField(primary_key=True)
    sname = models.CharField(max_length=50)
    slink = models.CharField(max_length=100)

class UserInfo(models.Model):
    id = models.AutoField(primary_key=True)
    uname = models.CharField(max_length=50)
    uaddress = models.CharField(max_length=100)

class CommitInfo(models.Model):
    id = models.AutoField(primary_key=True)
    curl = models.CharField(max_length=50)
    ctitle = models.CharField(max_length=50)
    csize = models.CharField(max_length=50)
    ccontact = models.CharField(max_length=50)
    cdesc = models.CharField(max_length=50)