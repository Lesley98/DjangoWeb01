from django.shortcuts import render

from bs4 import BeautifulSoup

import urllib

from urllib.parse import quote
import re
import time
from app import models


def index(request):
    return render(request, "index.html")

def commit(request):

    commitlist = {'url2':request.POST['upurl'],
                  'title2':request.POST['uptitle'],
                  'size2':request.POST['upsize'],
                  'contact2':request.POST['upcontact'],
                  'desc2':request.POST['updesc']}

    commiturl2 = commitlist['url2']
    committitle2 = commitlist['title2']
    commitsize2 = commitlist['size2']
    commitcontact2 = commitlist['contact2']
    commitdesc2 = commitlist['desc2']

    try:

       # models.CommitInfo.objects.create(curl=commiturl2, ctitle=committitle2,csize=commitsize2,ccontact=commitcontact2,cdesc=commitdesc2)
        print('save success')

    except:

        print('save failed')

    return render(request, "success3.html")


class Result:

    def success(request):
        return render(request, "success.html")
    def failed(request):

        return render(request,"failed.html")

def saveinfo(request):

    infolist = {'username':request.POST['uname'],
                'useraddress':request.POST['uaddress']}
    username2 = infolist['username']
    useraddress2 = infolist['useraddress']

    try:

        models.UserInfo.objects.create(uname=username2, uaddress=useraddress2)
        print('save success')

    except:

        print('save failed')

    return render(request,"success2.html")

class SourceManage:

    lista = {}

    def search(request):

        if request.POST:

            start = time.time()
            mname = request.POST['q']
            mcode = quote(mname)
            SourceManage.lista = {'name': request.POST['q'],
                                  'link': 'http://www.btbtdy.com/search/' + mcode + '.html',
                                  'content': 'temp',
                                  'uptime': 'temp',
                                  'times': 'temp'
                                  }

            url = SourceManage.lista.get('link')
            page = urllib.request.urlopen(url)
            html = page.read()
            bs = BeautifulSoup(html)
            rs = bs.find('div', class_="list_so")
            sorry = "对不起，没有找到任何记录,"
            if sorry in str(rs):
                return render(request, "failed.html",SourceManage.lista)
            else:
                title = bs.find_all('a', class_="so_pic")
                r = r'href="(.+?)" '
                title = re.findall(r, str(title[0]))
                url2 = "http://www.btbtdy.com" + title[0]
                print(url2)
                page2 = urllib.request.urlopen(url2)
                html2 = page2.read()
                bs2 = BeautifulSoup(html2)
                present = bs2.find_all('div', class_="c05")
                present2 = re.findall("[\u4E00-\u9FA5]", str(present[0]))
                present3 = "电影介绍："
                for index in range(len(present2)):
                    present3 = present3 + present2[index]

                uptime = bs2.find_all('span', class_="year")
                uptime2 = re.findall('\d{4}', str(uptime[0]))
                end = time.time()
                duration = end - start
                SourceManage.lista = {'name': request.POST['q'],
                                      'link': url2,
                                      'content': present3,
                                      'time': uptime2,
                                      'times': str(duration)}
                print(SourceManage.lista)

            return render(request, "search.html", SourceManage.lista)

    def detail(request):

        return render(request, "detail.html", SourceManage.lista)

    def save(request):

        moviename = SourceManage.lista['name']
        movielink = SourceManage.lista['link']

        try:

            models.Source.objects.create(sname=moviename, slink=movielink)
            print('save success')

        except:

            print('save failed')

        return render(request, "success.html")
