
from django.contrib import admin
from django.urls import path,include

from app import views

urlpatterns = [

    path('index/', views.index),
    path('commit/',views.commit),
    path('search/',views.SourceManage.search),
    path('detail/',views.SourceManage.detail),
    path('save/',views.SourceManage.save),
    path('success/',views.Result.success),
    path('failed/',views.Result.failed),
    path('saveinfo/',views.saveinfo)
]
